# AMS Chatbot Widget v3.0

Floating chat widget for AMS Clinic with avatar button and embedded chatbot.

---

## What's Included

```
ams-chatbot-widget/
  ams-chatbot-widget.php        ← WordPress plugin file
  README.md                     ← This file
  assets/
    chatbotpix.png              ← Avatar image (floating button)
    ams-chatbot-voiceflow.html  ← Chatbot UI (loaded in iframe)
    logoams.png                 ← AMS runner logo (chat header)
    robotams.png                ← Avatar for bot messages inside chat
```

---

## WordPress Installation

### Step 1 — Download the ZIP

Download `ams-chatbot-widget.zip` from wherever you received it. Do **not** unzip it.

### Step 2 — Upload to WordPress

1. Log into your WordPress admin dashboard
2. Go to **Plugins → Add New → Upload Plugin**
3. Click **Choose File** and select the `ams-chatbot-widget.zip`
4. Click **Install Now**
5. Click **Activate**

### Step 3 — Done

The floating chat button will now appear on every page of your site, bottom-right corner.

---

## How It Works

- The plugin injects a floating button and hidden chat box into every page via `wp_footer`
- Clicking the button opens a 380×650px chat window with the chatbot loaded in an iframe
- On mobile (under 640px), the chat goes fullscreen and locks page scroll
- The close button (X) appears on mobile; on desktop, Voiceflow's built-in close sends a postMessage
- All assets load from the plugin's own folder — no external CDNs or dependencies

---

## Updating the Chatbot

The chatbot UI lives in `assets/ams-chatbot-voiceflow.html`. To update it:

1. Go to **Plugins → Plugin Editor** (or use FTP/SFTP)
2. Select "AMS Chatbot Widget" from the dropdown
3. Navigate to `assets/ams-chatbot-voiceflow.html`
4. Make your changes and save

Or replace the file directly via FTP at:
```
/wp-content/plugins/ams-chatbot-widget/assets/ams-chatbot-voiceflow.html
```

---

## Customization

| What                  | Where / How                                                      |
|-----------------------|------------------------------------------------------------------|
| Button size           | `.chat-icon-wrap` — change `width: 90px`                         |
| Button position       | `#chatToggleBtn` — change `bottom` and `right` values            |
| Float animation speed | `gentleFloat` keyframes — change `3s` duration                   |
| Chat window size      | `#chatBox` — change `width: 380px` and `height: 650px`           |
| Replace avatar image  | Swap `assets/chatbotpix.png` with new image (keep same filename) |
| Replace header logo   | Swap `assets/logoams.png` (white PNG on transparent background)  |

---

## v3.0 Changes from v2.0

- **Removed** speech bubble overlay, peekaboo animation, and typing dots from floating button
- **Smaller button** — 90px circular avatar instead of 150px with clip-path layers
- **Gentler animation** — subtle vertical float instead of aggressive wobble + rotation
- **No tap square on mobile** — added `-webkit-tap-highlight-color: transparent`
- **No iOS zoom on input** — input font-size set to 16px, viewport locked
- **Dynamic viewport** — uses `100dvh` for proper mobile keyboard handling
- **Clean circular avatar** — `border-radius: 50%` with `object-fit: cover`

---

## Uninstalling

1. Go to **Plugins → Installed Plugins**
2. Click **Deactivate** under "AMS Chatbot Widget"
3. Click **Delete**

This removes all plugin files. No database entries are created.

---

## Troubleshooting

**Button doesn't appear:**
- Check that the plugin is activated in Plugins → Installed Plugins
- Check for JavaScript errors in browser console (F12)
- Some themes may not call `wp_footer()` — ensure your theme's footer.php has `<?php wp_footer(); ?>`

**Chat window is blank:**
- Verify `assets/ams-chatbot-voiceflow.html` exists in the plugin folder
- Check browser console for iframe loading errors
- Ensure your server isn't blocking iframe same-origin requests

**Images broken:**
- Verify all 4 files exist in the `assets/` folder
- Check file permissions (should be readable: 644)

**iOS zooms when typing:**
- This is fixed in v3.0. If you're using a custom `ams-chatbot-voiceflow.html`, ensure the input field has `font-size: 16px` and the viewport meta includes `maximum-scale=1.0`
